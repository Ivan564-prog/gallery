from django.apps import AppConfig

class StreamfieldConfig(AppConfig):
    name = 'streamfield'